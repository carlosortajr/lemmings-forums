[size=12pt][color=#8811FF][b]Effectively Remove SMF Logo[/b][/color][/size]

[hr][b]Author: [url=http://www.simplemachines.org/community/index.php?action=profile;u=182638]Labradoodle-360[/url][/b]
[b]Latest Version:[/b] 2.0
[b]Compatible With SMF:[/b] 2.0 & 2.0.1[hr]


[hr][size=12pt][color=#8811FF]Summary[/color][/size][hr]
Effectively Remove SMF Logo is the most effective way to remove the SMF Logo from your forum! It not only removes the SMF Logo from the template, but it also goes behind the scenes and removes the CSS for the logo, as well as the image itself! So all traces of the logo are gone! This mod is only available for the SMF 2.0 branch.

This also allows for a Site Slogan to still be shown.
[hr]


[hr][size=12pt][color=#8811FF]Languages[/color][/size][hr]
(No strings added)
[hr]


[hr][size=12pt][color=#8811FF]Installation[/color][/size][hr]
[b]Package Manager[/b] should work in most cases. If you need to make any edits, the full list can be obtained from the Parse function on the right.

[b]Useful links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]
[hr]

[hr][size=12pt][color=#8811FF]Version 2.0 Changelog[/color][/size][hr]
[b][color=green]+[/color][/b]) Updated for SMF 2.0 and SMF 2.0.1.
[b][color=gray]![/color][/b]) Bugfix: smflogo.png was not included in previous versions which caused problems when uninstalling modification.
[hr]


[hr][size=12pt][color=#8811FF]Files modified by Effectively Remove SMF Logo[/color][/size][hr]
[b][i]Theme Files (./Themes/default)[/i][/b]
[list][li]index.template.php[/li][/list]
[b][i]CSS Files (./Themes/default/css)[/i][/b]
[list][li]index.css[/li][/list]
[b][i]Files Removed[/i][/b]
[list][li]./Themes/default/images/smflogo.png[/li][/list]
[hr]


[hr][url=http://custom.simplemachines.org/mods/index.php?mod=2383]Link to Mod[/url] | [url=https://www.paypal.com/cgi-bin/webscr&cmd=_s-xclick&hosted_button_id=10240245]Support Labradoodle-360[/url][hr]